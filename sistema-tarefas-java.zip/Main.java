public class Main {
    public static void main(String[] args) {
        TarefaService service = new TarefaService();
        service.menu();
    }
}